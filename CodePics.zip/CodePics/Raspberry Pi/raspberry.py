import RPi.GPIO as GPIO
import paho.mqtt.client as mqtt
import time

# GPIO pin for the LED
led_pin = 18 #led pin assigned to 18
# Callback when a message is received from MQTT
def on_message(client, userdata, message):
    try:
        # Extract numeric part of the payload (excluding ' cm')
        distance_str = message.payload.decode().split(' ')[0]

        # Convert the extracted numeric part to a float
        distance = float(distance_str)

        print(f"Received distance value on topic {message.topic}: {distance} cm")

        if distance < 50:
            # Light up the LED
            GPIO.output(led_pin, GPIO.HIGH)
            print("LED ON")

           

            # wait for 1 second
            time.sleep(1)

            # Turn off the LED
            GPIO.output(led_pin, GPIO.LOW)
            print("LED OFF")

        else:
            # Turn off the LED
            GPIO.output(led_pin, GPIO.LOW)
            print("LED OFF")

    except ValueError as e:
        print(f"Error parsing distance value: {e}")

# MQTT broker settings
mqtt_server = "test.mosquitto.org"
mqtt_port = 1883
mqtt_topic = "hello/world"  #  the topic to subscribe to

# Set up GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(led_pin, GPIO.OUT)
GPIO.output(led_pin, GPIO.LOW)  # Initialize LED to OFF

# Set up MQTT client
client = mqtt.Client()
client.on_message = on_message
client.connect(mqtt_server, mqtt_port, 60)
client.subscribe(mqtt_topic)

try:
    print(f"Waiting for MQTT messages on topic {mqtt_topic}...")
    client.loop_forever()

except KeyboardInterrupt:
    print("Cleaning up GPIO and exiting.")
    GPIO.cleanup()
    client.disconnect()
